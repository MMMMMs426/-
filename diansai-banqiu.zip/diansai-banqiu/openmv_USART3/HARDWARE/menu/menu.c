#include "menu.h"
#include "oled.h"
#include "key.h"
#include "stm32f10x.h"
#include "stdio.h"
#include "bmp.h"
#include "stdio.h"
#include "pwm.h"
//2023/04/08                ?��????
// stm32mini ??????   key0--->next          wake_up --->enter 
 
void (*current_operation_index)();       //??��??????????
uint8_t func_index = 0;
int key_state;                           //?????????????
u8 taskFlag;
Menu_table table[19] =
{
		{0, 0, 1, (*fun0)},     //???????
		
		{1,2,7,(*fun1)},
		{2,1,3,(*fun2)},
		
		{3,4,11,(*fun3)},
		{4,5,12,(*fun4)},
		{5,6,13,(*fun5)},
		{6,3,14,(*fun6)},

		{7,8,15,(*fun7)},
		{8,9,16,(*fun8)},
		{9,10,17,(*fun9)},
		{10,7,18,(*fun10)},
		
		{11,11,1,(*fun11)},
		{12,12,1,(*fun12)},
		{13,13,1,(*fun13)},
		{14,14,1,(*fun14)},
		
		{15,15,1,(*fun15)},
		{16,16,1,(*fun16)},
		{17,17,1,(*fun17)},
		{18,18,1,(*fun18)},
		
};
void Menu_key_set(void)
{
    key_state = KEY_Scan(0);
    if (key_state == 1)
    {
			  OLED_Clear();
        func_index = table[func_index].next;
    }
		if(key_state == 2)
		{
		    TIM_SetCompare1(TIM3,14.5);
		}
    if(key_state == 3)
		{
			  OLED_Clear();
				func_index = table[func_index].enter;
		}
    current_operation_index = table[func_index].current_operation;
    (*current_operation_index)();
	}
void meun1_func(void)
{
    OLED_ShowString(0, 0, "   1.I    ", 16);
    OLED_ShowString(0, 2, "   2.II", 16);
}

void meun3_func(void)
{
    OLED_ShowString(0, 0, "   1.1    ", 16);
    OLED_ShowString(0, 2, "   2.2", 16);
    OLED_ShowString(0, 4, "   3.3", 16);
    OLED_ShowString(0, 6, "   4.4", 16);
}

void meun2_func(void)
{
    OLED_ShowString(0, 0, "   1.21    ", 16);
    OLED_ShowString(0, 2, "   2.22", 16);
    OLED_ShowString(0, 4, "   3.23", 16);
    OLED_ShowString(0, 6, "   4.24", 16);
}

void menu4_func(void)
{
	OLED_ShowString(0, 2, "	  back", 12);
}
void fun0(void)
{
	  OLED_DrawBMP(40,2,88,8,BMP2);
}
void fun1(void)
{
    meun1_func();
    OLED_ShowString(0, 0, "-> ", 16);
}

void fun2(void)
{
    meun1_func();
    OLED_ShowString(0, 2, "-> ", 16);
}

void fun3(void)
{
    meun2_func();
    OLED_ShowString(0, 0, "-> ", 16);
}

void fun4(void)
{
    meun2_func();
    OLED_ShowString(0, 2, "-> ", 16);
}
void fun5(void)
{
    meun2_func();
    OLED_ShowString(0, 4, "-> ", 16);
}

void fun6(void)
{
    meun2_func();
    OLED_ShowString(0, 6, "-> ", 16);
}

void fun7(void)
{
    meun3_func();
    OLED_ShowString(0, 0, "-> ", 16);
}

void fun8(void)
{
    meun3_func();
    OLED_ShowString(0, 2, "-> ", 16);
}

void fun9(void)
{
    meun3_func();
    OLED_ShowString(0, 4, "-> ", 16);
}

void fun10(void)
{
    meun3_func();
    OLED_ShowString(0, 6, "-> ", 16);
}

void fun11(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	taskFlag=5;
	//printf("21\r\n");
}

void fun12(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	taskFlag=6;
	//printf("22\r\n");
}

void fun13(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	taskFlag=7;
	//printf("23\r\n");
}

void fun14(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	
	taskFlag=8;
	//printf("24\r\n");
}

void fun15(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	  taskFlag=1;
	//printf("11\r\n");
}

void fun16(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	  taskFlag=2;
	//printf("12\r\n");
}

void fun17(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	  taskFlag=3;
	//printf("13\r\n");
}

void fun18(void)
{
    menu4_func();
    OLED_ShowString(0, 2, "-> ", 16);
	  taskFlag=4;
	//printf("14\r\n");
}



