#ifndef __MENU_H
#define __MENU_H

#include "stm32f10x.h"

extern u8 taskFlag;

//??��???
void Menu_key_set(void);
void menu1_func(void);
void menu2_func(void);
void menu3_func(void);
void menu4_func(void);

void fun0(void);
void fun1(void);
void fun2(void);
void fun3(void);
void fun4(void);
void fun5(void);
void fun6(void);
void fun7(void);
void fun8(void);
void fun9(void);
void fun10(void);
void fun11(void);
void fun12(void);
void fun13(void);void fun14(void);
void fun15(void);
void fun16(void);
void fun17(void);
void fun18(void);

typedef struct
{
    uint8_t current;  //???????????
    uint8_t next;     //???��? 
    uint8_t enter;    //???????
    void (*current_operation)(void);//??????????��????
}Menu_table;

extern uint8_t Data_current[8];
#endif /* __MENU_H */
