#include "task.h"
#include "pid.h"
#include "stdio.h"
#include "usart.h"
#include "timer.h"
#include "stdlib.h"
#include "usart2.h"

extern u8 taskFlag;
extern int timeflag;                         //�Ƿ���ж�ʱ
extern int lanyaflag;
int jinruflag=0;
int X_aim;
extern int x_now;
extern float kp,ki,kd;
static int count=0;
static int i = 0;
char a;
int k;
void task(void)
{     
	   PID(kp,ki,kd);
	   Set_PWM();
}
void task5(void)
{     
	   PID(kp,ki,kd);
	   Set_PWM1();
}
void task7(void)
{
	  X_aim = 113;
		task();
		if(x_now>113)
		{
			X_aim = 53;
			task();
			if(x_now<52)
			{
				i++;
				task7();
			}
		}
}
void choice(u8 taskflag)
{
	static u8 a;
	u8 dot;
  a	= taskFlag;
	//printf("%d\r\n",a);
	if(a == 1)
	{
		X_aim = 53;
		task();
	}
	else if(a == 2)
	{
		X_aim = 83;
		task();
	}
	else if(a == 3)
	{
		X_aim = 145;
		task5();
	}
	else if(a == 4)
	{
		//printf("timeflag = %d\r\n",timeflag);
		if(timeflag == 0)
		{
			X_aim = 53;
			task();
			if(jinruflag==0)
			{
				TIM2_Init(5000-1,7200-1);         //0.5s�ж�һ��   
				jinruflag = 1;
			}
		}	
		if(timeflag == 1)
		{
			 X_aim = 83;
			 task();
		}  
	}
	else if(a==5)
	{
		if(timeflag == 0)
		{
			X_aim = 83;
			task();
			if(jinruflag==0)
			{
				TIM2_Init(5000-1,7200-1);         //0.5s�ж�һ��   
				delay_ms(20);
				jinruflag = 1;
			}
		}	
		if(timeflag == 1)
		{
			 X_aim = 145;
			 task();
		}
		//printf("Jinru = %d,time = %d\r\n",jinruflag,timeflag);
	}
	else if(a == 6)
	{
for(i = 0;i<4;i++)
		{
			k =5;
			dot = USART2_RX_BUF[i];
			//printf("%c   \r\n",dot);
			if(dot == '1')
			{								
				while(1)  
				{
					X_aim = 20;
				  task();
					if(jinruflag == 0)
					{
						TIM2_Init(5000-1,7200-1);
						jinruflag = 1;
					}
					if(lanyaflag == 1)
						break;
				}
			}
			if(dot == '2')
			{
				while(1)
				{
					X_aim = 53;
					while(k)
				{
					if(x_now-X_aim>0&&x_now>66)
					{
						X_aim = 66;
						task();
					}
					else if(x_now-X_aim>0&&x_now<35)
					{
						X_aim = 35;
						task();
					}
					--k;
				}
				  task();
					if(jinruflag == 0)
					{
						TIM2_Init(5000-1,7200-1);
						jinruflag = 1;
					}
					if(lanyaflag == 1)
						break;
				}
			}
			if(dot == '3')
			{
				while(1)
				{
					X_aim = 83;
				  task();
					if(jinruflag == 0)
					{
						TIM2_Init(5000-1,7200-1);
						jinruflag = 1;
					}
					if(lanyaflag == 1)
						break;
				}
			}
			if(dot == '4')
			{
				while(1)
				{
					X_aim = 113;
				  task();
					if(jinruflag == 0)
					{
						TIM2_Init(5000-1,7200-1);
						jinruflag = 1;
					}
					if(lanyaflag == 1)
						break;
				}
			}
			if(dot == '5')
			{
				while(1)
				{
					X_aim = 145;
				  task();
					if(jinruflag == 0)
					{
						TIM2_Init(5000-1,7200-1);
						jinruflag = 1;
					}
					if(lanyaflag == 1)
						break;
				}
			}
			jinruflag = 0;
			lanyaflag = 0;
		}
	}
	else if(a == 7)
	{
		if(x_now<57&&x_now>46)
  {
   while(1)
   {
    X_aim = 93;
    task();
    if(x_now<114&&x_now>106)
     break;
   }
   count++;
  }
  if(x_now<114&&x_now>106)
  {
   while(1)
   {
    X_aim = 70;
     task();
    if(x_now<57&&x_now>50)
     break;
   } 
   count++;
  }
  if(count >= 8)
  {
   while(1)
   {
    X_aim = 145;
     task();
   }
  }
	}
	else if(a == 8)
	{
		X_aim = 83;
		task();
	}
	else if(a == 9)
	{
		
	}
	
}
