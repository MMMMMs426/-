#ifndef __TASK_H_
#define __TASK_H_	

#include "stm32f10x.h"


void task(void);
void choice(u8 taskflag);
void task7(void);
void task5(void);
#endif
